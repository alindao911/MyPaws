package charles09.alindao.com.mypaws;

/**
 * Created by Pc-user on 02/02/2018.
 */

public class InformationListDetails {
    private String settingsName;

    public InformationListDetails() {

    }

    public InformationListDetails(String settingsName) {
        this.settingsName = settingsName;
    }

    public String getSettingsName() {
        return settingsName;
    }

    public void setSettingsName(String settingsName) {
        this.settingsName = settingsName;
    }
}
